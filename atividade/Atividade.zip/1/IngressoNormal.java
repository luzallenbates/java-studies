public class IngressoNormal extends Ingresso {
    public IngressoNormal(double valor) {
        super(valor);
    }
}
