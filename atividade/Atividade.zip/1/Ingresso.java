public abstract class Ingresso {
    public double valor;

    public Ingresso(double valor) {
        this.valor = valor;
    }
}
