public class Imovel {
    double valor;
    String localizacao;
    public Imovel(double valor, String localizacao) {
        this.valor = valor;
        this.localizacao = localizacao;
    }
}
